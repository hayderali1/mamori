# Results scaffold (fill from real runs — cells intentionally blank)

> Replace every `—` with a number from `runs/<model>/mamori_metrics.csv`.
> Blank cells are a deliberate guard against reporting unmeasured numbers.

## Table A — ASR by language and defense (one block per model)

Model: **<MODEL NAME>**, suite: workspace, mode: plain.
ASR = attack success rate (lower is safer). `Gap` = ASR(ℓ) − ASR(en).

| Defense | en | de | tr | ko | ar | sw | Gap(tr) | Gap(ko) | Gap(sw) |
|---|---|---|---|---|---|---|---|---|---|
| none (baseline) | — | — | — | — | — | — | — | — | — |
| transformers_pi_detector | — | — | — | — | — | — | — | — | — |
| spotlighting_with_delimiting | — | — | — | — | — | — | — | — | — |
| repeat_user_prompt | — | — | — | — | — | — | — | — | — |
| tool_filter | — | — | — | — | — | — | — | — | — |

## Table B — Defense effectiveness Δ = ASR(none) − ASR(defense), by language

| Defense | en | de | tr | ko | ar | sw |
|---|---|---|---|---|---|---|
| transformers_pi_detector | — | — | — | — | — | — |
| spotlighting_with_delimiting | — | — | — | — | — | — |
| repeat_user_prompt | — | — | — | — | — | — |
| tool_filter | — | — | — | — | — | — |

## Table C — Adversarial conditions (H3): plain vs code-switch vs translit

| Lang | plain ASR | codeswitch ASR | translit ASR |
|---|---|---|---|
| de | — | — | n/a |
| tr | — | — | n/a |
| ko | — | — | — |
| ar | — | — | — |

## Table D — Benign utility under attack (robustness–usefulness trade-off)

| Defense | en | de | tr | ko | ar | sw |
|---|---|---|---|---|---|---|
| none | — | — | — | — | — | — |
| transformers_pi_detector | — | — | — | — | — | — |
| spotlighting_with_delimiting | — | — | — | — | — | — |

## Table E — Translation quality control (per language)

| Lang | carrier verified | % goals scaffold-matched | % MT-translated | COMET/back-translation |
|---|---|---|---|---|
| de | yes | — | — | — |
| tr | yes | — | — | — |
| ko | yes | — | — | — |
| ar | yes | — | — | — |
| sw | draft | — | — | — |

## Hypothesis verdicts (fill after analysis)

- **H1** (ASR rises as resource level falls): —
- **H2** (detector degrades most): —
- **H3** (code-switch/translit evade even high-resource): —
- **H4** (structured/alignment more robust but still leak): —
