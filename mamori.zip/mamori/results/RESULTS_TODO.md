# RESULTS_TODO — how to produce the real numbers

> **Integrity note.** Nothing in this repository contains experimental ASR/utility
> numbers, because they could not be produced in the build environment (no GPU, no
> API key, model downloads blocked). Every number in the paper must come from
> running the commands below on your own hardware. The only quantitative outputs
> generated so far are: (a) the multilingual **payload dataset**
> (`results/payloads_workspace.json`), and (b) a **synthetic metric self-test**
> (fixtures, not results). Do not put (b) in the paper.

## 0. Environment

```bash
pip install agentdojo vllm
pip install -e .          # this repo
```

You need either a GPU (open-weight models via vLLM) or an API key
(`ANTHROPIC_API_KEY` / `OPENAI_API_KEY` / Google) for the agent model, and — for
the detector defense — outbound access to HuggingFace to download
`protectai/deberta-v3-base-prompt-injection-v2`.

## 1. Reproduce English (Phase 1 of the proposal)

Validate the harness against the original AgentDojo numbers before going
multilingual.

```bash
LOCAL_LLM_PORT=8000 python scripts/run_mamori.py \
    --model local --model-id meta-llama/Meta-Llama-3-8B-Instruct \
    --suite workspace --languages en \
    --defenses none transformers_pi_detector spotlighting_with_delimiting repeat_user_prompt tool_filter
```

Confirm the English ASR/utility roughly match AgentDojo's published values.

## 2. Full cross-lingual grid (Phases 2–3)

Per model, sweep every defense × language × mode. Repeat the block for each
open-weight model in the proposal (Llama-3-8B, Mistral-7B, Qwen2.5-7B, Gemma-7B/9B)
and at least one strong multilingual model.

```bash
for MODEL_ID in \
  meta-llama/Meta-Llama-3-8B-Instruct \
  mistralai/Mistral-7B-Instruct-v0.3 \
  Qwen/Qwen2.5-7B-Instruct \
  google/gemma-2-9b-it ; do
    # (serve $MODEL_ID with vLLM on :8000 first)
    LOCAL_LLM_PORT=8000 python scripts/run_mamori.py \
        --model local --model-id "$MODEL_ID" \
        --suite workspace \
        --languages en de tr ko ar sw \
        --modes plain codeswitch translit \
        --defenses none transformers_pi_detector spotlighting_with_delimiting repeat_user_prompt tool_filter \
        --logdir "runs/$(basename $MODEL_ID)"
done
```

Also run the other suites for breadth: `--suite banking`, `--suite travel`,
`--suite slack`.

Outputs per run dir:
- `mamori_metrics.csv` / `.json` — per-cell ASR, utility, Gap(ℓ), Δ
- `translation_provenance.json` — which carrier/goal was verified vs MT vs fallback
- `leaderboard.csv` / `.json` — ranked configs by cross-lingual robustness

## 3. Fill the paper tables (Phase 4)

Paste the per-cell CSV into `paper/results_scaffold.md` (the placeholder tables
already match the metrics columns). Then test the hypotheses:

- **H1** — regress ASR on `resource_level` (high→low). Expect ASR↑.
- **H2** — compare Δ for `transformers_pi_detector` vs structured/hardening defenses
  across languages. Expect the detector's Δ to collapse most on non-English.
- **H3** — compare `plain` vs `codeswitch`/`translit` ASR even for `en`/`de`.
- **H4** — `spotlighting_with_delimiting` / `repeat_user_prompt` should keep more Δ
  than the detector but still show a positive `Gap(ℓ)`.

## 4. Translation quality control (so degradation isn't blamed on bad MT)

Before trusting non-English ASR, verify translation quality on the sampled subset
the proposal promises:
- Inspect `translation_provenance.json`; anything with `goal_verified=false` or
  `codeswitch_fallback=true` needs either a verified scaffold (add to
  `translations.GOAL_SCAFFOLDS`) or native-speaker sign-off on the MT output.
- Record back-translation / COMET scores per language and report them next to ASR
  so a referee can rule out broken-translation confounds.

## 5. Release (Phase 5)

Publish `results/payloads_*.json`, the harness, the per-model run dirs, and the
aggregated leaderboard. Add a short defenders' guide (multilingual detector
fine-tuning as the mitigation pointer).
